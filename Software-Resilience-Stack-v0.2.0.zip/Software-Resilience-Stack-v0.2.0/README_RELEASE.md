# Software Resilience Stack v0.2.0

A hardened engineering release of the v0.1.0 evidence-validation PoC.

Start with `core/RELEASE.md`, then `core/README.md`.

This release is intentionally scoped. Real free-threaded runtime causality, production SLSA trust, external held-out evaluation, and threshold calibration remain open.
